#!/bin/sh
# Tests script
cd ../go/src/github.com/kind84/subito-test
go test -v  